<?php
// start the session
session_start();
//require setup file for database connection
require_once("setup.php");
//create a variable that we'll use to reset the isLoggedIn value, so they're able to log back
$logoutvalue = 0;

//check both table for the email, this is okay since the email cant exist in both tables at the same time anyway.
                    $stmt = $conn->prepare("UPDATE users SET isLoggedIn = ? WHERE email = ?");
					$stmt->bind_param("is", $logoutvalue, $_SESSION["email"]);
					$stmt->execute();
					$stmt->close();

                    $stmt2 = $conn->prepare("UPDATE employee SET isLoggedIn = ? WHERE email = ?");
					$stmt2->bind_param("is", $logoutvalue, $_SESSION["email"]);
					$stmt2->execute();
					$stmt2->close();
//if there is no session, redirect to homepage.
if(session_destroy()){
   header("location: homepage.php");
}

?>