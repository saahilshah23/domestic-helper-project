<?php
session_start();

require_once("setup.php");
include 'sessionTime.php';
//redirect automatically to the employee profile page, employees dont need to be accessing user profiles.
if (isset($_SESSION["EmpID"])) {
    echo '<script language="javascript">';
    echo 'window.location.href = "ProfileEmp.php";';
    echo '</script>';
} else if ($_SESSION['email']) {
    // do nothing, theres no need to!
    include 'LoggedInNavbars.php';
} else {
    header('Location: homepage.php'); //redirect back to homepage so users can access any info
}
//database connect binded to variable
$conn = mysqli_connect("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20") or die("something went wrong, please try again!");


?>




<?php
//any variables related to a service, unset them
if (isset($_SESSION['servicename'])) {
    unset($_SESSION['servicename'], $_SESSION['servicedesc'], $_SESSION['location'], $_SESSION['rating'], $_SESSION['price'], $_SESSION['employeename']);
}
//if active button is pressed, search the database for details matching the current row in the table on webpage, and delete them from the database.
if (isset($_POST['deleteActiveBooking'])) {

    //bind values of row to variables.
    $customID = $_POST['CustomID'];
    $bookingID = $_POST['BookingID'];
    $servicename = $_POST['servicename'];
    $servicedesc = $_POST['servicedesc'];
    $location = $_POST['location'];
    $time = $_POST['Time'];
    $date = $_POST['Date'];
    $endtime = $_POST['Endtime'];
    $acceptedBy = $_POST['acceptedBy'];

    //prepared statement binded to variable
    $stmt = $conn->prepare("SELECT BookingID, CustomID FROM activeBookings WHERE BookingID = ? OR CustomID = ?");

    //if execution of $stmt is successful, check database for either the a matching bookingID OR customID, if it exists, delete that row.
    if ($stmt) {
        $stmt->bind_param("ii", $bookingID, $customID);
        $stmt->execute();
        $stmt->bind_result($bookingID, $customID);
        $stmt->store_result();
        $stmt->fetch();
        $count = $stmt->num_rows;

        if ($count > 0) {
            $stmt = $conn->prepare("DELETE FROM activeBookings WHERE (BookingID = ?) OR (CustomID = ?)");
            $stmt->bind_param("ii", $bookingID, $customID);
            $stmt->execute();
            $stmt->close();

?>
            <!-- throw alert of successful deletion of row -->
            <script>
                Swal.fire({
                    icon: 'success',
                    title: 'Booking Deleted',
                    showConfirmButton: false,
                    timer: 2000
                });
            </script>
        <?php
        }
        // throw error if an issue (mostly to show if theres an issue on the developer side.)
        else {
        ?>
            <script>
                Swal.fire({
                    icon: 'Error.',
                    title: 'Something went wrong.',
                    showConfirmButton: false,
                    timer: 2000
                });
            </script>
        <?php
        }
    }
}
//same process as deleteActiveBooking above but for booking requests that have been made. Is a little easier because it only needs to check for a BookingID, no CustomID
else if (isset($_POST['deleteBookingRequest'])) {



    $bookingID = $_POST['BookingID'];
    $servicename = $_POST['servicename'];
    $servicedesc = $_POST['servicedesc'];
    $location = $_POST['location'];
    $time = $_POST['Time'];
    $date = $_POST['Date'];
    $endtime = $_POST['Endtime'];
    $acceptedBy = $_POST['acceptedBy'];

    $stmt = $conn->prepare("SELECT BookingID, Time, Date FROM Bookings WHERE BookingID = ? AND Time = ? AND Date = ?  ");

    if ($stmt) {
        $stmt->bind_param("iss", $bookingID, $time, $date);
        $stmt->execute();
        $stmt->bind_result($bookingID, $time, $date);
        $stmt->store_result();
        $stmt->fetch();
        $count = $stmt->num_rows;

        if ($count > 0) {

            $stmt = $conn->prepare("DELETE FROM Bookings WHERE BookingID = ?");
            $stmt->bind_param("i", $bookingID);
            $stmt->execute();
            $stmt->close();

        ?>
            <script>
                Swal.fire({
                    icon: 'success',
                    title: 'Booking Deleted.',
                    showConfirmButton: false,
                    timer: 2000
                });
            </script>

        <?php
        }
    } else {
        ?>
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Something went wrong.',
                showConfirmButton: false,
                timer: 2000
            });
        </script>

        <?php
    }
}
//same as above two but for deleting custom requests made by the user.
else if (isset($_POST['deleteCustomRequest'])) {


    $customID = $_POST['customID'];
    $requestedByUser = $_POST['requestedByUser'];
    $servicename = $_POST['servicename'];
    $servicedesc = $_POST['servicedesc'];
    $location = $_POST['location'];
    $time = $_POST['Time'];
    $date = $_POST['Date'];
    $endtime = $_POST['Endtime'];
    $price = $_POST['price'];


    $stmt = $conn->prepare("SELECT CustomID, Time, Date, requestedByUser FROM customRequests WHERE CustomID = ? AND Time = ? AND Date = ? AND requestedByUser = ?");

    if ($stmt) {
        $stmt->bind_param("issi", $customID, $time, $date, $requestedByUser);
        $stmt->execute();
        $stmt->bind_result($customID, $time, $date, $requestedByUser);
        $stmt->store_result();
        $stmt->fetch();
        $count = $stmt->num_rows;
        if ($count > 0) {
            $stmt = $conn->prepare("DELETE FROM customRequests WHERE CustomID = ?");
            $stmt->bind_param("i", $customID);
            $stmt->execute();
            $stmt->close();

        ?>
            <script>
                Swal.fire({
                    icon: 'success',
                    title: 'Custom Request Deleted.',
                    showConfirmButton: false,
                    timer: 2000
                });
            </script>
        <?php
        } else {
        ?>
            <script>
                Swal.fire({
                    icon: 'error',
                    title: 'Custom Request Delete failed, please try again.',
                    showConfirmButton: false,
                    timer: 2000
                });
            </script>
        <?php
        }
    } else {
        ?>
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Something went wrong, please try again later.',
                showConfirmButton: false,
                timer: 2000
            });
        </script>
    <?php
    }
}
// not the same as the above 3, once this button is pressed, it will take you to the leave review page where the user can leave a review for a service they have had done.
else if (isset($_POST['submit4'])) {


    $customID = $_POST['customID'];
    $requestedByUser = $_POST['requestedByUser'];
    $servicename = $_POST['servicename'];
    $servicedesc = $_POST['servicedesc'];
    $location = $_POST['location'];
    $time = $_POST['Time'];
    $date = $_POST['Date'];
    $endtime = $_POST['Endtime'];
    $price = $_POST['price'];

    //match the details of the current row and see if they exist in the database.
    $stmt = $conn->prepare("SELECT BookingID, Time, Date, requestedByUser FROM completedBookings WHERE bookingID = ? AND Time = ? AND Date = ? AND requestedByUser = ?");
    $stmt->bind_param("issi", $bookingID, $time, $date, $requestedByUser);
    $stmt->execute();
    $stmt->bind_result($bookingID, $time, $date, $requestedByUser);
    $stmt->store_result();
    $stmt->fetch();
    $count = $stmt->num_rows;



    if ($count > 0) {
        //do nothing, show the leave review page.
    } else {

    ?>
        <!-- details dont exist in database, throw below error -->
        <script>
            Swal.fire({
                icon: 'Error.',
                title: 'Something went wrong.',
                showConfirmButton: false,
                timer: 2000
            });
        </script>
    <?php
    }
}
// below executes when the viewReview button is pressed, this is only accessible once you have gone through the elseif on line 215, since you need to leave a review first in order to see it.
else if (isset($_POST['viewReview'])) {


    $customID = $_POST['customID'];
    $requestedByUser = $_POST['requestedByUser'];
    $servicename = $_POST['servicename'];
    $servicedesc = $_POST['servicedesc'];
    $location = $_POST['location'];
    $time = $_POST['Time'];
    $date = $_POST['Date'];
    $endtime = $_POST['Endtime'];
    $price = $_POST['price'];
    $bookingID = $_POST['BookingID'];

    $sql = $conn->query("SELECT CustomID, Time, Date FROM customRequests WHERE Time = '$time' AND Date = '$date' AND requestedByUser = '$requestedByUser'"); //change this to a prepared statement if you can!!

    if ($sql->num_rows > 0) {
        //do nothing, show the view review page.
    } else {

    ?>
        <!-- if they dont exist in the database, throw this error (should not be able to happen anyway, since the rows within the completedBookings section of profile are being pulled from database) -->
        <script>
            Swal.fire({
                icon: 'Error.',
                title: 'Something went wrong.',
                showConfirmButton: false,
                timer: 2000
            });
        </script>
<?php
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>DomesticHelper</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- stylesheet imports such as bootstrap and fontawesome -->
    <!--===============================================================================================-->
    <link rel="icon" type="image/png" href="images/icons/favicon.ico" />
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="css/util.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!--===============================================================================================-->
    <style>
        h4,
        h5 {
            text-align: center;
        }

        body {
            text-align: center;
            background: url(https://wallpaperaccess.com/full/3898677.jpg);
            background-repeat: no-repeat;
            background-size: 1920px 1080px;
        }

        /* adding a border around table, each header and each element of each row. */
        table,
        th,
        td {
            border: 1px solid black;

        }

        /* centering the table in the middle of the screen, could have been done by ID but chose class. */
        .tablecenter {
            margin-left: auto;
            margin-right: auto;
        }

        /* font family of the customers table, alongside the width of the table itself */
        #customers {
            font-family: Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 50%;
        }

        /* styling of each header element and each element in each row */
        #customers td,
        #customers th {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }

        /*alternating colours of each row of the table to give it a better look */
        #customers tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        #customers tr:nth-child(ODD) {
            background-color: #DDD;
        }

        /*background colour of our table rows under each of the 4 big buttons */
        #customers tr:hover {
            background-color: #ddd;
        }

        /*styling of our table headers under each of the 4 big buttons */
        #customers th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: center;
            background-color: #04AA6D;
            color: white;
        }

        /* css button styles, credit to HTML Goodies - code found here : https://www.htmlgoodies.com/css/css-button-styles/ */


        .viewButton {
            display: inline-block;
            background-color: #3CB371;
            border-radius: 10px;
            color: white;
            text-align: center;
            font-size: 13px;
            padding: 20px;
            height: 20px;
            width: 100px;
            transition: all 0.5s;
            cursor: pointer;
            margin: 5px;
            line-height: 0px;
        }

        .viewButton input {
            cursor: pointer;
            display: inline-block;
            position: relative;
            transition: 0.5s;
        }

        .viewButton input:after {
            content: '0bb';
            position: absolute;
            opacity: 0;
            top: 0;
            right: -20px;
            transition: 0.5s;
        }

        .viewButton:hover {
            background-color: white;
            color: black;
        }

        .viewButton:hover input {
            padding-right: 25px;

        }

        .viewButtonhover input:after {
            opacity: 1;
            right: 0;
        }


        /* button stying */
        #showReview,
        #leaveReview {
            padding: 0px;
            width: 100px;
            height: 50px;
        }

        /* leave review is orange colour, signifying that the user can do something here */
        #leaveReview {
            background-color: #ffa500;
        }

        /* big profile buttons turn white when hovered over */
        #big4:hover {
            background-color: white;
            color: black;
            transition-duration: 0.5s;
            cursor: pointer;
        }

        /* once a button on profile page is clicked (one of the 4 big ones) it will highlight white to show its been pressed) */
        #big4:focus {
            background-color: white;
            color: black;
        }

        /* chose red to signify delete instead of green since users assume green as a 'yes' colour, and mightly unintentionally press it */
        #cancelButton {
            background-color: #F52D2D;
        }
    </style>

<body>
    <br>
    <h4>Profile page for user: <?php echo $_SESSION['fname'] . " " . $_SESSION['sname'];   ?></h4> <!-- displays the users name on the profile page -->
    <br>
    <a class="btn btn-primary glyphicon glyphicon-search" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample" id="big4">
        <h4>Booking Requests</h4>
        &#8595;
    </a>
    <!-- booking requests table, shown once button is clicked -->
    <div class="collapse" id="collapseExample">
        <div class="card-body">
            <table class="tablecenter" id="customers">
                <thead>
                    <tr>
                        <th>Booking ID</th>
                        <th>Service Name</th>
                        <th>Service Description</th>
                        <th>Location</th>
                        <th>Date</th>
                        <th>Start Time</th>
                        <th>End Time</th>
                        <th>Accepted By</th>
                        <th>Cancel</th>
                    </tr>
                </thead>

                <?php
                $conn = new mysqli("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20"); //connect to Database
                $id = $_SESSION['id']; //bind session id (users id) to a variable

                //throw error if cant connect to database
                if ($conn->connect_error) {
                    die("Connection error: " . $conn->connection_error);
                }
                //run a database query, and show results within the table format starting on line 509.
                $query = "SELECT BookingID, servicename, servicedesc, location, Date, Time, endtime, acceptedBy, ServiceID FROM Bookings WHERE id = '$id' ";
                $res = $conn->query($query);

                while ($row = $res->fetch_assoc()) {

                    echo "<tr>";
                    echo "<td>" . $row['BookingID'] . " " . "</td>";
                    echo "<td>" . $row['servicename'] . " " . "</td>";
                    echo "<td>" . $row['servicedesc'] . " " . "</td>";
                    echo "<td>" . $row['location'] . " " . "</td>";
                    echo "<td>" . $row['Date'] . " " . "</td>";
                    echo "<td>" . $row['Time'] . " " . "</td>";
                    echo "<td>" . $row['endtime'] . " " . "</td>";
                    echo "<td>" . $row['acceptedBy'] . " " . "</td>";
                    //form via a button that one pressed, will be able to delete the current row the button is on from the database.
                    echo "<td><form method=post>
                                 <input name=BookingID type=hidden value='" . $row['BookingID'] . "'>
                                 <input name=servicename type=hidden value='" . $row['servicename'] . "'>
                                 <input name=servicedesc type=hidden value='" . $row['servicedesc'] . "'>
                                 <input name=location type=hidden value='" . $row['location'] . "'>

                                 <input name=Time type=hidden value='" . $row['Time'] . "'>
                                 <input name=Endtime type=hidden value='" . $row['endtime'] . "'>
                                 <input name=Date type=hidden value='" . $row['Date'] . "'>
                                 <input name=acceptedBy type=hidden value='" . $row['acceptedBy'] . "'>
                                 <input type=submit name=deleteBookingRequest class=viewButton id=cancelButton value=Cancel></form></td>";
                    echo "</tr>";
                }
                $conn->close(); //stop database connection
                ?>
            </table>
        </div>
    </div>

    <!-- ongoing jobs section -->
    <a class="btn btn-primary glyphicon glyphicon-search" data-toggle="collapse" href="#collapseExample2" role="button" aria-expanded="false" aria-controls="collapseExample" id="big4">
        <h4>Ongoing Jobs</h4>
        &#8595;

    </a>
    <!-- table that will show the ongoing jobs listed in the database -->
    <div class="collapse" id="collapseExample2">
        <div class="card-body">
            <table class="tablecenter" id="customers">
                <thead>
                    <tr>
                        <th>Custom ID</th>
                        <th>Booking ID</th>
                        <th>Service Name</th>
                        <th>Service Description</th>
                        <th>Location</th>
                        <th>Date</th>
                        <th>Start Time</th>
                        <th>End Time</th>
                        <th>Accepted By</th>
                        <th>Cancel</th>

                    </tr>
                </thead>

                <?php
                $conn = new mysqli("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20"); //connect to database
                $id = $_SESSION['id']; //bind session id (users id) to a variable
                //throw error if cant connect to database
                if ($conn->connect_error) {
                    die("Connection error: " . $conn->connection_error);
                }
                //run a database query, and show results that match the current user ID within the table format starting on line 579.
                $query = "SELECT * FROM activeBookings WHERE id = '$id' ";
                $res = $conn->query($query);



                while ($row = $res->fetch_assoc()) {

                    echo "<tr>";
                    echo "<td>" . $row['CustomID'] . " " . "</td>";
                    echo "<td>" . $row['BookingID'] . " " . "</td>";
                    echo "<td>" . $row['servicename'] . " " . "</td>";
                    echo "<td>" . $row['servicedesc'] . " " . "</td>";
                    echo "<td>" . $row['location'] . " " . "</td>";
                    echo "<td>" . $row['Date'] . " " . "</td>";
                    echo "<td>" . $row['Time'] . " " . "</td>";
                    echo "<td>" . $row['endtime'] . " " . "</td>";
                    echo "<td>" . $row['acceptedBy'] . " " . "</td>";
                    //form via a button that one pressed, will be able to delete the current row the button is on from the database.
                    echo "<td><form method=post>
                                <input name=CustomID type=hidden value='" . $row['CustomID'] . "'>
                                 <input name=BookingID type=hidden value='" . $row['BookingID'] . "'>
                                 <input name=servicename type=hidden value='" . $row['servicename'] . "'>
                                 <input name=servicedesc type=hidden value='" . $row['servicedesc'] . "'>
                                 <input name=Time type=hidden value='" . $row['Time'] . "'>
                                 <input name=Endtime type=hidden value='" . $row['endtime'] . "'>
                                 <input name=Date type=hidden value='" . $row['Date'] . "'>
                                 <input name=acceptedBy type=hidden value='" . $row['acceptedBy'] . "'>
                                 <input name=location type=hidden value='" . $row['location'] . "'>
                                 
                                 <input type=submit name=deleteActiveBooking class=viewButton value=Delete></form></td>";
                    echo "</tr>";
                }
                $conn->close(); //stop database connection
                ?>
            </table>
        </div>
    </div>
    <!-- custom requests jobs section -->
    <a class="btn btn-primary glyphicon glyphicon-search" data-toggle="collapse" href="#collapseExample3" role="button" aria-expanded="false" aria-controls="collapseExample" id="big4">
        <h4>Custom Requests</h4>
        &#8595;
    </a>

    <div class="collapse" id="collapseExample3">
        <div class="card-body">
            <!-- table that will show the custom request jobs listed in the database -->
            <table class="tablecenter" id="customers">
                <thead>
                    <tr>
                        <th>Custom ID</th>
                        <th>User ID</th>
                        <th>Service Name</th>
                        <th>Service Description</th>
                        <th>Location</th>
                        <th>Date</th>
                        <th>Start Time</th>
                        <th>End Time</th>
                        <th>Price</th>
                        <th>Cancel</th>
                    </tr>
                </thead>

                <?php
                $conn = new mysqli("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20"); //connect to database
                $id = $_SESSION['id']; //bind session id (users id) to a variable
                //throw error if cant connect to database
                if ($conn->connect_error) {
                    die("Connection error: " . $conn->connection_error);
                }

                //run a database query, and show results that match the current user ID within the table format starting on line 650.
                $query = "SELECT * FROM customRequests WHERE requestedByUser = '$id' ";
                $res = $conn->query($query);



                while ($row = $res->fetch_assoc()) {

                    echo "<tr>";
                    echo "<td>" . $row['CustomID'] . " " . "</td>";
                    echo "<td>" . $row['requestedByUser'] . " " . "</td>";

                    echo "<td>" . $row['servicename'] . " " . "</td>";
                    echo "<td>" . $row['servicedesc'] . " " . "</td>";
                    echo "<td>" . $row['location'] . " " . "</td>";
                    echo "<td>" . $row['Date'] . " " . "</td>";
                    echo "<td>" . $row['Time'] . " " . "</td>";
                    echo "<td>" . $row['endtime'] . " " . "</td>";
                    echo "<td>" . $row['price'] . " " . "</td>";
                    //form via a button that one pressed, will be able to delete the current row the button is on from the database.
                    echo "<td><form method=post>
                             <input name=customID type=hidden value='" . $row['CustomID'] . "'>
                             <input name=requestedByUser type=hidden value='" . $row['requestedByUser'] . "'>
                             <input name=servicename type=hidden value='" . $row['servicename'] . "'>
                             <input name=servicedesc type=hidden value='" . $row['servicedesc'] . "'>
                             <input name=Time type=hidden value='" . $row['Time'] . "'>
                             <input name=Endtime type=hidden value='" . $row['endtime'] . "'>
                             <input name=Date type=hidden value='" . $row['Date'] . "'>
                             <input name=price type=hidden value='" . $row['price'] . "'>
                             <input name=location type=hidden value='" . $row['location'] . "'>
                             <input type=submit name=deleteCustomRequest class=viewButton value=Delete></form></td>";
                    echo "</tr>";
                }

                $conn->close(); //stop database connection
                ?>
            </table>
        </div>
    </div>

    <!-- completed jobs section -->
    <a class="btn btn-primary glyphicon glyphicon-search" data-toggle="collapse" href="#collapseExample4" role="button" aria-expanded="false" aria-controls="collapseExample" id="big4">
        <h4>Completed Bookings</h4>
        &#8595;
    </a>

    <div class="collapse" id="collapseExample4">
        <div class="card-body">
            <!-- table that will show the completed jobs listed in the database -->
            <table class="tablecenter" id="customers">
                <thead>
                    <tr>
                        <th>Service Name</th>
                        <th>Service Description</th>
                        <th>Location</th>
                        <th>Date</th>
                        <th>Start Time</th>
                        <th>End Time</th>
                        <th>Completed By</th>
                        <th>Review</th>
                    </tr>
                </thead>

                <?php
                $conn = new mysqli("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20"); //connect to database
                $id = $_SESSION['id']; //bind session id (users id) to a variable
                //throw error if cant connect to database
                if ($conn->connect_error) {
                    die("Connection error: " . $conn->connection_error);
                }
                // run a query that will show all completed bookings matching the current user id in table format starting on line 718.
                $query = "SELECT * FROM completedBookings WHERE id = '$id' ";
                $res = $conn->query($query);

                while ($row = $res->fetch_assoc()) {

                    echo "<tr>";
                    echo "<td>" . $row['servicename'] . " " . "</td>";
                    echo "<td>" . $row['servicedesc'] . " " . "</td>";
                    echo "<td>" . $row['location'] . " " . "</td>";
                    echo "<td>" . $row['Date'] . " " . "</td>";
                    echo "<td>" . $row['Time'] . " " . "</td>";
                    echo "<td>" . $row['endtime'] . " " . "</td>";
                    echo "<td>" . $row['acceptedBy'] . " " . "</td>";

                    //create forms based on if a review has been left currently.
                    if (($row['LeftReview']) == 'No') {
                        echo "<td><form action=reviewService.php method=post>";
                    } else if (($row['LeftReview']) == 'Yes') {
                        echo "<td><form action=showReview.php method=post>";
                    }


                    echo        "<input name=servicename type=hidden value='" . $row['servicename'] . "'>";
                    echo        "<input name=BookingID type=hidden value='" . $row['BookingID'] . "'>";
                    echo        "<input name=ServiceID type=hidden value='" . $row['ServiceID'] . "'>";
                    echo        "<input name=EmpID type=hidden value='" . $row['EmpID'] . "'>";
                    echo        "<input name=servicedesc type=hidden value='" . $row['servicedesc'] . "'>";
                    echo        "<input name=Time type=hidden value='" . $row['Time'] . "'>";
                    echo        "<input name=Endtime type=hidden value='" . $row['endtime'] . "'>";
                    echo        "<input name=Date type=hidden value='" . $row['Date'] . "'>";
                    echo        "<input name=location type=hidden value='" . $row['location'] . "'>";
                    echo        "<input name=acceptedBy type=hidden value='" . $row['acceptedBy'] . "'>";


                    // create if statement here, if a review already exists, insert a 'show review' button, otherwise, 'leave review button', otherwise its a custom request, which we wont allow reviews for.
                    if (($row['LeftReview']) == 'No') {
                        echo "<input type=submit name=submit4 class=viewButton id=leaveReview value='leave review'>";
                    } else if (($row['LeftReview']) == 'Yes') {
                        echo "<input type=submit name=viewReview class=viewButton id=showReview value='show review'>";
                    } else {
                        echo "<td><p>Review not available.</p></td>";
                    }

                    echo "</form></td>";
                    echo "</tr>";
                }
                $conn->close(); //stop database connection
                ?>

            </table>
        </div>
    </div>
</body>

</html>