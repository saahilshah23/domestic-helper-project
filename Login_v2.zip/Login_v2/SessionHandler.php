<!-- Session done from tutorial video: source to video is: https://www.youtube.com/watch?v=vESwDXV81F0 -->

<!-- initialise session variable, linked to Login.php -->
<?php
session_start();
include 'setup.php';

if ($_SESSION['email']) {
    $_SESSION['sessionTime'] = time();
    // redirect to profile page if employee, services page if user after 2 seconds
    header("Refresh:2; url=Services.php");
} else {
    header('Location: Login.php'); //redirect back to login.php so users can access any info
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <style>
        body {
            text-align: center;
        }
    </style>

<body>
   



    <script>
        Swal.fire({
            icon: 'success',
            title: 'Welcome <?php echo $_SESSION['fname'] . " " . $_SESSION['sname'] ?>, redirecting...',
            showConfirmButton: false,
            timer: 2000
        }).then(function() {
            window.location = "https://raptor.kent.ac.uk/proj/comp6000/project/20/Login_v2/Services.php";
        });
    </script>



</body>
</head>