<?php
// start session
session_start();
//initalise normal navbart, database connection and session time
require_once('setup.php');
include 'LoggedInNavbars.php';
include 'sessionTime.php';

// if there is not session, redirect to the homepage, the starting page.
if (!$_SESSION) {
	

	echo '<script type="text/javascript">';
	echo 'window.location.href="homepage.php";';
	echo '</script>';
}
//database connection - remove this if possible, not mandatory.
$conn = mysqli_connect("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20") or die("something went wrong, please try again!");

if (isset($_POST['submit'])) {

	//bind our post variables to variables we can use later
	$id = $conn->real_escape_string($_SESSION['id']);
	$servicename = $_POST['servicename'];
	$location = $_POST['location'];
	$price = $_POST['price'];
	$servicedesc = $_POST['servicedesc'];
	$time = $_POST['time'];
	$endtime = $_POST['endtime'];
	$date = $_POST['date'];
	if ($price > 0) {

	    //MySQLi prepared statement
		$stmt = $conn->prepare("INSERT INTO customRequests (requestedByUser,servicename, servicedesc, location, price, Time, endtime, Date) VALUES (?,?,?,?,?,?,?,?)");
		//bind our variables to each respective ?, with their type: i = int, s = string.
		$stmt->bind_param("isssisss",$id, $servicename, $servicedesc, $location, $price, $time, $endtime, $date);
		$stmt->execute();
?>
	   <!-- show alert to the user -->
		<script>
			Swal.fire({
				icon: 'success',
				title: 'Success!',
				text: 'Custom Request Sent',
				showConfirmButton: false,
			})
		</script>
		<!-- javascript redirect back to profile php after 2 seconds -->
		<script>
			window.setTimeout(function() {
				window.location = 'Profile.php';
			}, 2000);
		</script>
	<?php
	} 
	//if price is not greater than 0.
	else {
	?>
		<script>
			Swal.fire({
				icon: 'warning',
				title: 'Something went wrong...',
				text: 'Please make price greater than 0.',
			})
		</script>
<?php
	}
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<style>
		/* stying for our container */
		#containerstyling {
			padding-bottom: 100px;
		}
		/* styling for our navbar, at the bottom of the browser */
		#bottomnav {
			background-color: #333;
			overflow: hidden;

			bottom: 0;
			width: 100%;
		}
	</style>
	<!-- import bootstrap CDN -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<title>DomesticHelper</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Bootstrap files, fontawesome and JQuery files -->

	<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="images/icons/favicon.ico" />
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.css">
</head>


<!-- time picker that allows user to pick times -->
<script src="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.js"></script>

<body>

	<script>
		//credit for timepicker code - timepicker.co - source code here: https://timepicker.co/
		//choose time in hourly format, ranging from 8am to 8pm

		(function($) {
			$(function() {
				$('input.timepicker').timepicker({
					timeFormat: 'HH:mm',
					interval: 60,
					minTime: '8',
					maxTime: '8:00pm',
					defaultTime: '8',
					startTime: '08:00',
					dynamic: false,
					dropdown: true,
					scrollbar: true,

				});

			});
		})(jQuery);
	</script>
	<script>
		//credit for timepicker code - timepicker.co - source code here: https://timepicker.co/

		(function($) {
			$(function() {
				$('input.timepicker2').timepicker({
					timeFormat: 'HH:mm',
					interval: 60,
					minTime: '8',
					maxTime: '8:00pm',
					defaultTime: '9',
					startTime: '08:00',
					dynamic: false,
					dropdown: true,
					scrollbar: true,

				});

			});
		})(jQuery);
	</script>


	<div class="limiter">
		<div class="container-login100" id="containerstyling">
			<div class="wrap-login100">
				<!-- form for the user to fill out -->
				<form class="login100-form validate-form" method="post">
					<span class="login100-form-title p-b-26">
						New Service
					</span>
					<!-- image of our logo -->
					<span class="login100-form-title p-b-48">
						<img src="../logo/DomesticLogo2.png" style="height: 200px; width: 250px">
					</span>
                    <!-- name of the service the user would like to request -->
					<div class="wrap-input100 validate-input">
						<p>Service name</p>
						<input class="input100" name="servicename" type="servicename" id="servicename" maxlength="50" required>
						<span class="focus-input100"></span>
					</div>
                    <!-- Description of the service -->
					<div class="wrap-input100 validate-input">
						<p>Service description</p>
						<input class="input100" name="servicedesc" type="servicedesc" id="servicedesc" required maxlength="150">
						<span class="focus-input100"></span>
					</div>
                    <!-- Location where they'd like the service -->
					<div class="wrap-input100 validate-input">
						<p>Location</p>
						<input class="input100" name="location" type="location" id="location" maxlength="60" required>
						<span class="focus-input100"></span>
					</div>
                    <!-- Date they'd like the job on -->
					<div class="wrap-input100 validate-input">
						<p>Date</p>
						<input type="date" id="date" name="date" required>
					</div>
					<!-- Time for the job to start -->
					<div class="wrap-input100 validate-input">
						<p>Time</p>
						<input class="timepicker" name="time" id="time" maxlength="0"> <!-- Stop users inputting custom times -->
					</div>
					<!-- Time for the job to end -->
					<div class="wrap-input100 validate-input">
						<p>End Time</p>
						<input class="timepicker2" name="endtime" id="endtime" maxlength="0"> <!-- Stop users inputting custom times -->
					</div>


					<!-- How much they;re offering for the job -->
					<div class="wrap-input100 validate-input">
						<p>Price</p>
						<input class="input100" name="price" type="price" id="price" required>
						<span class="focus-input100"></span>
					</div>
<br>
<br>
<br>
					<div class="container-login100-form-btn">
						<div class="wrap-login100-form-btn">
							<div class="login100-form-bgbtn"></div>
							<!-- Button to submit the form -->
							<button class="login100-form-btn" type="submit" name="submit" href="profile.php">
								Submit
							</button>
						</div>
					</div>

					<div class="text-center p-t-115">
						<!-- Anchor tag to go back to login page, which in turn will take you back to services.php -->
						<a class="txt2" href="login.php">
							Go back
						</a>
					</div>
				</form>
			</div>
		</div>
	</div>

	<!-- declare our AJAX function, once register button is clicked, confirm entered detials match database -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script type="text/javascript">


	</script>


</body>
<div>
	<!-- Footer with names of project members on -->
	<p class="footertext" style="color:white" id="bottomnav">Website created by Sam, Tope, Saahil</p>

</div>

</html>