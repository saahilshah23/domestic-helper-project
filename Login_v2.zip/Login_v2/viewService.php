<?php
session_start();
include 'sessionTime.php';
if ($_SESSION['email']) {
	// do nothing, theres no need to!
	include 'LoggedInNavbars.php';
} else {
	header('Location: Login.php'); //redirect back to login.php so users can access any info
}
//set all the variables of the service within $_SESSION, this is to prevent the variables from returning undefined when a new request is sent to the browser( CTRL + F5).
if (!isset($_SESSION['servicename'])) {
	$_SESSION['servicename'] = $_POST['servicename'];
	$_SESSION['servicedesc'] = $_POST['servicedesc'];
	$_SESSION['location'] = $_POST['location'];
	$_SESSION['rating'] = $_POST['rating'];
	$_SESSION['price'] = $_POST['price'];
	$_SESSION['employeename'] = $_POST['employeename'];
	$_SESSION['serviceID'] = $_POST['ServiceID'];
}
//if button with name submit is pressed, run the below isset
if (isset($_POST['submit'])) {

	$conn = new mysqli("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20"); //connection to DB

	$servicename = $_POST['servicename'];
	$servicedesc = $_POST['servicedesc'];
	//if the checkbox is selected, use the values in the 3 inputs of address1,2,3 and concatenate them to give the different address, ready for inserting into database, otherwise use the address
	// already registered on the account
	if (!isset($_POST['registeredAddress'])) {
		$location = $_POST['address1'] . ", " . $_POST['address2'] . ", " . $_POST['address3'];
	} else {
		$location = $_SESSION['address'] . ", " . $_SESSION['City'];
	}
  // append rest of post values to their own variables.
	$rating = $_POST['rating'];
	$price = $_POST['price'];
	$time = $_POST['time'];
	$endtime = $_POST['endtime'];
	$date = $_POST['date'];
	$serviceID = $_POST['ServiceID'];
	$EmpID = $_POST['EmpID'];
	$userID = $_SESSION['id'];
	$currentdate = date("Y-m-d"); //get current date in same format as database.
	$currenttime = date("H:i:s"); //get current time in 24h format (same as the time and endtime selections on this webpage).


	//if the date selected by the user is less than the current date, throw error and dont submit form, else, move on to checking the time.
	if ($date < $currentdate) {
?>
		<script>
			Swal.fire({
				icon: 'warning',
				text: 'Date is in the past/invalid, please amend.',
				showConfirmButton: false,
				timer: 3000
			})
		</script>


	<?php
		// if the date is the same as the current date and the time is less than real time, throw error, if not, continoue.
	} else if (($date == $currentdate) && ($time < $currenttime)) {
	?>
		<script>
			Swal.fire({
				icon: 'warning',
				text: 'Time or endtime is in the past, please amend.',
				showConfirmButton: false,
				timer: 3000
			})
		</script>


		<?php
	} else {

		// -- $sql2 stops bookings being prevented that are inside the timeslots of other bookings.('$time' >= Time AND '$endtime' <= endtime) 
		// -- $sql3 stops endtime overlapping with another booking -- ('$time' <= Time AND '$endtime' >= Time)
		// -- $sql4 stops time overlaps with another booking -- ('$time' >= Time AND '$time' <= endtime)
		$sql2 = $conn->query("SELECT ServiceID, Time, endtime, Date FROM Bookings WHERE Date = '$date' AND ServiceID = '$serviceID' AND ('$time' >= Time AND '$endtime' <= endtime)");
		$sql3 = $conn->query("SELECT ServiceID, Time, endtime, Date FROM Bookings WHERE Date = '$date' AND ServiceID = '$serviceID' AND ('$time' >= Time AND '$time' <= endtime)");
		$sql4 = $conn->query("SELECT ServiceID, Time, endtime, Date FROM Bookings WHERE Date = '$date' AND ServiceID = '$serviceID' AND ('$time' <= Time AND '$endtime' >= Time)");



         //if greater than 1, throw error
		if ($sql2->num_rows > 0) {
		?>
			<script>
				Swal.fire({
					icon: 'warning',
					text: 'Your booking start time and endtime interfere with another booking, please amend both of these values.',
					showConfirmButton: true,
				})
			</script>

				
		<?php
		//if greater than 1, throw error
		} else if ($sql3->num_rows > 0) {
		?>
			<script>
				Swal.fire({
					icon: 'warning',
					text: 'Your start time interferes with another booking, please make this earlier!',
					showConfirmButton: true,
				})
			</script>


		<?php
		//if greater than 1, throw error
		} else if ($sql4->num_rows > 0) {
		?>
			<script>
				Swal.fire({
					icon: 'warning',
					text: 'Your end time interferes with another booking, please make this earlier. If your booking is for one hour only, please also adjust your start time.',
					showConfirmButton: true,

				})
			</script>


		<?php
		//tells user to adjust their endtime.
		} else if ($endtime < $time) {
		?>
			<script>
				Swal.fire({
					icon: 'warning',
					text: 'Endtime is before start time, please amend.',
					showConfirmButton: true,

				})
			</script>


		<?php
		//tells user they cant have both the same time for start and finish.
		} elseif ($endtime == $time) {
		?>
			<script>
				Swal.fire({
					icon: 'warning',
					text: 'Start time and endtime are the same, please amend.',
					showConfirmButton: true,

				})
			</script>


		<?php
		//otherwise the booking becomes successful, allows for insertion into database, returns alert informing user it was successful. then redirect back to profile
		} else {


			$conn->query("INSERT INTO Bookings (servicename, servicedesc, location, Date, Time, endtime, id, ServiceID, EmpID, acceptedBy) VALUES ('$servicename', '$servicedesc', '$location', '$date', '$time', '$endtime', '$userID','$serviceID', '$EmpID', 'Awaiting Confirmation')");

		?>
			<script>
				Swal.fire({
					icon: 'success',
					text: 'Booking Requested.',
					showConfirmButton: false,
					timer: 3000

				})
			</script>
			<script>
				window.setTimeout(function() {
					window.location = 'Profile.php';
				}, 3000);
			</script>


<?php
		}
	}
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<title>DomesticHelper</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- stylesheets for bootstrap, fontawesome -->
	<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="images/icons/favicon.ico" />
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<!--===============================================================================================-->

	<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.css">

</head>
<style>
	/* styling elements for all our inputs, form width and height and table (and its contents) */
	.wrap-login100 {
		width: 6000px;
		height: 1200px;
		margin-bottom: 125px;

	}

	.wrap-input100 {
		width: 25%;
		margin: 5px;
	}

	.center {
		width: 25%;
		text-align: center;

		margin-left: 80%;
	}

	.dateTime {
		width: 175%;
	}

	.timepicker {
		border: 1px solid;
	}

	.timepicker2 {
		border: 1px solid;
	}

	.txt2 {
		bottom: 0;
		right: 0;
	}

	table,
	td,
	th {
		border: 1px solid black;
	}

	table {
		border-collapse: collapse;
		width: 100%;
		margin-left: 10px;
	}

	td {
		height: 20px;
		vertical-align: bottom;
		width: 50%;
	}

	th {
		width: 25%;
	}
  /* our service section */
	#serviceDetails {
		width: 30%;
		margin-right: auto;
		margin-left: 200px;
	}
    /* our recent reviews section */
	#reviewDetails {
		width: 40%;
		height: 550px;
		margin-bottom: auto;
		margin-left: auto;
		margin-right: 200px;
		background-color: transparent;
		position: static;

	}

	.full-width {
		width: 100%;
	}
    /*keep stars on a single line */
	.nowrapstars {
		white-space: nowrap;
	}
	/* colour of stars in recent reviews */
	.checked {
		color: orange;
	}
    /* colour of disabled inputs when checkbox is checked */
	.greyedout {
		background-color: #C7E0EB;

	}
</style>
<script src="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.js"></script>

<body>

	<script>
		//credit for timepicker code - timepicker.co - source code here: https://timepicker.co/ - allows use to select hourly times based on below, can choose from between 8am to 7pm in 1h intervals for start time

		(function($) {
			$(function() {
				$('input.timepicker').timepicker({
					timeFormat: 'HH:mm',
					interval: 60,
					minTime: '8',
					maxTime: '7:00pm',
					defaultTime: '8',
					startTime: '08:00',
					dynamic: false,
					dropdown: true,
					scrollbar: true,

				});

			});
		})(jQuery);
	</script>
	<script>
		//credit for timepicker code - timepicker.co - source code here: https://timepicker.co/ - allows use to select hourly times based on below, can choose from between 9am to 8pm in 1h intervals for finish time

		(function($) {
			$(function() {
				$('input.timepicker2').timepicker({
					timeFormat: 'HH:mm',
					interval: 60,
					minTime: '8',
					maxTime: '8:00pm',
					defaultTime: '9',
					startTime: '08:00',
					dynamic: false,
					dropdown: true,
					scrollbar: true,

				});

			});
		})(jQuery);
	</script>

	



	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100" id="serviceDetails">
				<!-- this returns the data you want if you put it inside the form, but we need it outside the form so it does not interfere with the date -->
					<form class="login100-form validate-form p-b 20" method="post" id="form1">
					<span class="login100-form-title">
						Viewing Service<br>
					</span>


					<p>Service Name</p>
					<div class="wrap-input100 validate-input" id="divheightadjust">
						<input class="input100" name="servicename" type="servicename" id="servicename" value="<?php print_r($_SESSION['servicename']); ?>" required readonly="readonly" onkeypress="if (event.keyCode == 13) {return false;}">
						<span class="focus-input100"></span>
					</div>


					<p>Service Description</p>
					<div class="wrap-input100 validate-input full-width">
						<input class="input100" name="servicedesc" type="servicedesc" id="servicedesc" value="<?php print_r($_SESSION['servicedesc']); ?>" required readonly="readonly" onkeypress="if (event.keyCode == 13) {return false;}">
						<span class="focus-input100"></span>
					</div>


					<p>Area Service Covers</p>
					<div class="wrap-input100 validate-input full-width">
						<input class="input100" name="location" type="location" id="location" value="<?php print_r($_SESSION['location']); ?>" required readonly="readonly" onkeypress="if (event.keyCode == 13) {return false;}">
						<span class="focus-input100"></span>
					</div>
					<br>
					<p>Address of Job</p>
					<div class="checkbox">
					<label class="customer-control-label" for="customControlInLine"> <input type="checkbox" name="registeredAddress" class="custom-contrtol-input" id="checkBox" onclick="disable()" onkeypress="if (event.keyCode == 13) {return false;}"> Same as registered address</label>
					</div>

					<p>House number and Road</p>
					<div class="wrap-input100 validate-input full-width">
						<input class="input100 address" name="address1" type="text" onkeypress="if (event.keyCode == 13) {return false;}" required>
						<span class="focus-input100"></span>
					</div>

					<p>City</p>
					<div class="wrap-input100 validate-input full-width">
						<input class="input100 address" name="address2" type="text" onkeypress="if (event.keyCode == 13)  {return false;}" required>
						<span class="focus-input100"></span>
					</div>

					<p>Post Code</p>
					<div class="wrap-input100 validate-input">
						<input class="input100 address" name="address3" type="text" required maxlength="7">
						<span class="focus-input100"></span>
					</div>
					<!-- source credit to disable multiple inputs via checkbox -  tymeJV JSFiddle Linked here - http://jsfiddle.net/SM8Nx/5/ Comment for it found here - https://stackoverflow.com/questions/15909258/disable-or-enable-multiple-inputs -->

					<script>
						function disable() {
							var elements = document.getElementsByClassName("address");
							document.getElementById("checkBox").checked ? doIt(elements, true) : doIt(elements, false);
						}

						function doIt(elements, status) {
							for (var i = 0; i < elements.length; i++) {
								elements[i].disabled = status;
							}
						}
                        //disable inputs of the type text that the user could enter details in, reenable if unchecked.
						$("#checkBox").click(function() {

							if ($(this).is(":checked")) {
								$('.address').addClass("greyedout");
							    $('input[type="text"]').prop('required', false);

							} else {
								$('.address').removeClass("greyedout");
								$('input[type="text"]').prop('required', true);

							}
						});
					</script>


					<p>Service Rating (out of 5)</p>
					<div class="wrap-input100 validate-input">
						<input class="input100" name="rating" type="rating" id="rating" value="<?php print_r($_SESSION['rating']) ?>" required readonly="readonly" maxlength="5" onkeypress="if (event.keyCode == 13) {return false;}">
						<span class="focus-input100"></span>
					</div>
					<p>Service Price (in £)</p>
					<div class="wrap-input100 validate-input">
						<input class="input100" name="price" type="price" id="price" value="<?php print_r($_SESSION['price']); ?>" readonly="readonly" onkeypress="if (event.keyCode == 13) {return false;}">
						<span class="focus-input100"></span>
					</div>

					<p>Offered By</p>
					<div class="wrap-input100 validate-input">
						<input class="input100" name="employeename" type="employeename" id="employeename" value="<?php print_r($_SESSION['employeename']); ?>" readonly="readonly" maxlength="3" onkeypress="if (event.keyCode == 13) {return false;}">
						<span class="focus-input100"></span>
					</div>


					<!-- pass the id through for the service but make it invisible on the viewService screen -->
					<input class="input100" name="ServiceID" type="hidden" id="ServiceID" value="<?php print_r($_POST['ServiceID']); ?>" readonly="readonly">
					<input class="input100" name="EmpID" type="hidden" id="EmpID" value="<?php print_r($_POST['EmpID']); ?>" readonly="readonly">
					<span class="focus-input100"></span>


					<div required>
						<!-- required on input not working for some reason... -->
						<p>Date</p>
						<input type="date" id="date" name="date">
					</div>
					<div>
						<p>Time</p>
						<input class="timepicker" name="time" id="time" maxlength="0"> <!-- Stop users inputting custom times -->
					</div>

					<div>
						<p>End Time</p>
						<input class="timepicker2" name="endtime" id="endtime" maxlength="0"> <!-- Stop users inputting custom times -->
					</div>

					<div class="center">
						<div class="wrap-login100-form-btn">
							<div class="login100-form-bgbtn"></div>
                            <!-- button to make the button, executing the isset near the start of this file, also when clicked it will run the function myFuction -->
							<button class="login100-form-btn" type="submit" name="submit" onclick="myFunction()">
								Make a booking
							</button>

						</div>
                        <!-- return to the services page if user changes mind -->
						<a class="txt2 p-b 20" href="Services.php">
							Go back
						</a>
					</div>

					<script>
						const form = document.querySelector('form[action=""]'); // Form
						const inputs = form.querySelectorAll('input'); // All input elements inside the form
						const submit = form.querySelector('button[type="submit"]'); // Submit button inside the form

						// Add onclick event to the form button
						submit.addEventListener('click', function(event) {
							event.preventDefault(); // This prevents the button from submitting the form the traditional way
							submit_form(); // but instead our way
						});

						function submit_form() {
							// We iterate through the form input elements
							for (var i = 0; i < inputs.length; i++) {
								// We check if the current element has
								// the attribute required and if so
								// we proceed with checks
								if (inputs[i].hasAttribute('required') && inputs[i].value.length == 0) {
									inputs[i].focus(); // We focus on the required element
									alert(inputs[i].placeholder + ' is required!'); // Alert the user that the element is required
									break; // Break from the loop
								} else {
									if (i == (inputs.length - 1)) form.submit(); // If the loop's i variable counter hits the same value as the
									// input elements length then it means all fields are filled
								}
							}
						}
					</script>
				</form>

			</div>
			<div class="wrap-login100" id="reviewDetails">
				<!-- this returns the data you want if you put it inside the form, but we need it outside the form so it does not interfere with the date -->
				<span class="login100-form-title">
					Recent Reviews
					<br>
					<br>

				</span>

				<?php

				$conn = new mysqli("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20"); //database connection
				$userID = $_SESSION["id"]; //assign current id for user to a variable
				$stars = ""; //variable for stars, for reviews
				$serviceID = $_SESSION["serviceID"]; //assign current id for service to a variable
				$query = "SELECT reviewdescription, rating, location, date, reviewedBy FROM reviews WHERE serviceID = '$serviceID' ORDER BY Date LIMIT 3 "; //$query says to fetch reviews that match the current service id, which is stored in the users session (check line 23)
				$res = $conn->query($query);
				while ($row = $res->fetch_assoc()) {
					//this process here determines the current rating of each row, if it is within 0.2 of 0.5 (so 0.3-0.7) then we consider that a half star in the rating
					$reviewdescription = $row['reviewdescription'];
					$rating = $row['rating'];
					$date = $row['date'];
					$reviewedBy = $row['reviewedBy'];
					$stars = "";

					if (($row['rating'] >= 0.3) && ($row['rating'] <= 0.7)) {
						$stars .= '<i class="fa fa-star-half checked"></i>';
						$stars .= '<i class="fa fa-star-half fa-flip-horizontal "></i>';
						$stars .= '<i class="fa fa-star"></i>';
						$stars .= '<i class="fa fa-star"></i>';
						$stars .= '<i class="fa fa-star"></i>';
						$stars .= '<i class="fa fa-star"></i>';
					} elseif ($row['rating'] < 0.3) {
						$stars .= '<i class="fa fa-star"></i>';
						$stars .= '<i class="fa fa-star"></i>';
						$stars .= '<i class="fa fa-star"></i>';
						$stars .= '<i class="fa fa-star"></i>';
						$stars .= '<i class="fa fa-star"></i>';
					} else {

						for ($i = 0; $i < $row['rating']; $i++) {
							if ($i + 0.5 < $row['rating']) {
								$stars .= '<i class="fa fa-star checked"></i>';
							} else {
								$stars .= '<i class="fa fa-star-half checked"></i>';
								$stars .= '<i class="fa fa-star-half fa-flip-horizontal "></i>';
							}
						}

						for ($i = 5; $i > $row['rating']; $i--) {
							if ($i > $row['rating']) {
								if ($i - 1 < $row['rating']) {
									//$stars .= '<i class="fa fa-star-half"></i>';  
								} else {
									$stars .= '<i class="fa fa-star"></i>';
								}
							}
						}
					}
                    //display the final star rating, alongside the user who made the review, the date the job was done, and what they said in their review
					echo "<td class=nowrapstars>" . $stars . " " . "</td>";
					echo "<strong>" . $row['reviewedBy'] . "</strong>" . " - " . $row['date'];
					echo "<br>";
					echo "<i>'" .  $row['reviewdescription'] . "'</i>";
					echo "<br>";
					echo "<br>";
					echo "<br>";
				}

				?>
			</div>
		</div>
	</div>

	<!-- declare our AJAX function, once register button is clicked, confirm entered detials match database -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
</body>

</html>